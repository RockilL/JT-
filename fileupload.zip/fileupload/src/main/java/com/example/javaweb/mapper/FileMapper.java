package com.example.javaweb.mapper;

import com.example.javaweb.domain.FileInfo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FileMapper {
    @Insert("INSERT INTO file(file_name, file_path) VALUES(#{fileName}, #{filePath})")
    void saveFile(FileInfo fileInfo); // 保存文件信息到数据库
}