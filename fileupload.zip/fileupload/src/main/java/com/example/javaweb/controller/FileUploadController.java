package com.example.javaweb.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@RestController
@RequestMapping("/files")//设置路径
public class FileUploadController {

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {//ResponseEntity<String>返回完整响应
        if (file.isEmpty()) {//MultipartFile用于处理文件上传的接口，定义各种方法
            return ResponseEntity.badRequest().body("文件为空");
        }

        try {
            // 设置上传路径
            String uploadDir = "/usr/lib";//保存在服务器的位置
            File dest = new File(uploadDir + file.getOriginalFilename());//两个连起来就是要放入的地址，File 类是 Java 提供的一个用于表示文件和目录的类
            file.transferTo(dest);//用MultipartFile的方法保存到指定路径
            return ResponseEntity.ok("文件上传成功：" + dest.getAbsolutePath());
        } catch (IOException e) {
            return ResponseEntity.status(500).body("文件上传失败：" + e.getMessage());
        }
    }
}
