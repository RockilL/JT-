package com.example.javaweb.domain;
import lombok.Data;

    @Data
    public class FileInfo {
        private Long id;            // 文件的唯一标识符
        private String fileName;    // 文件名
        private String filePath;    // 文件存储路径
    }
